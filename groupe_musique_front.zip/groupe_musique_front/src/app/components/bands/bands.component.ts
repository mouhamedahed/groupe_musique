import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Band, BandService } from '../../services/band-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-import-bands',
    imports: [CommonModule,FormsModule,RouterModule], 
  
  templateUrl: './bands.component.html',
  styleUrls: ['./bands.component.css']
})
export class ImportBandsComponent {
  selectedFile: File | null = null;
  bands: Band[] = [];
  editingBand: Band | null = null;
  constructor(private http: HttpClient,
    private bandService: BandService
  ) {}

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }

  uploadFile() {
    if (!this.selectedFile) {
      alert('Veuillez sélectionner un fichier.');
      return;
    }

    const formData = new FormData();
    formData.append('file', this.selectedFile);

    this.http.post('http://localhost:8000/api/bands/import', formData)
      .subscribe({
        next: () => alert('Importation réussie !'),
        error: (error) => console.error('Erreur lors de l\'importation', error)
      });
  }

  ngOnInit(): void {
    this.fetchBands();
  }



  fetchBands(): void {
    this.bandService.getBands().subscribe((data) => {
      this.bands = data;
    });
  }

  editBand(band: Band): void {
    this.editingBand = { ...band };
  }

  saveBand(): void {
    if (!this.editingBand || !this.editingBand.id || !this.editingBand.name) {
      alert("Veuillez remplir tous les champs obligatoires.");
      return;
    }
  
    this.bandService.updateBand(this.editingBand.id, this.editingBand).subscribe(() => {
      this.fetchBands();
      this.editingBand = null;
    });
  }
  

  deleteBand(id: any): void {
    if (confirm('Voulez-vous vraiment supprimer ce groupe ?')) {
      this.bandService.deleteBand(id).subscribe(() => {
        this.bands = this.bands.filter(b => b.id !== id);
      });
    }
  }

}
