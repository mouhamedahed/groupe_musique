import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportBandsComponent } from './bands.component';

describe('BandsComponent', () => {
  let component: ImportBandsComponent;
  let fixture: ComponentFixture<ImportBandsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ImportBandsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ImportBandsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
