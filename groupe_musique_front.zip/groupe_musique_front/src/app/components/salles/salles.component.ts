import { Component, OnInit } from '@angular/core';
import { Salle, SalleService } from '../../services/salle-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-salles',
  standalone: true,
    imports: [CommonModule,FormsModule,RouterModule], 
  templateUrl: './salles.component.html',
  styleUrls: ['./salles.component.css']
})
export class SallesComponent implements OnInit {
  salles: Salle[] = [];
  newSalle: Salle = { name: '', capacite: 0,adresse:'' };
  editingSalle: Salle | null = null;

  constructor(private salleService: SalleService) {}

  ngOnInit(): void {
    this.fetchSalles();
  }

  fetchSalles(): void {
    this.salleService.getSalles().subscribe((data) => {
      this.salles = data;
    });
  }

  addSalle(): void {
    if (!this.newSalle.name || this.newSalle.capacite <= 0|| !this.newSalle.adresse) {
      alert('Veuillez entrer un nom, une adresse et une capacité valide.');
      return;
    }
    this.salleService.addSalle(this.newSalle).subscribe(() => {
      this.fetchSalles();
      this.newSalle = { name: '', capacite: 0,adresse:'' };
    });
  }

  editSalle(salle: Salle): void {
    this.editingSalle = { ...salle };
  }

  saveSalle(): void {
    if (this.editingSalle) {
      this.salleService.updateSalle(this.editingSalle.id!, this.editingSalle).subscribe(() => {
        this.fetchSalles();
        this.editingSalle = null;
      });
    }
  }

  deleteSalle(id: number): void {
    if (confirm('Voulez-vous vraiment supprimer cette salle ?')) {
      this.salleService.deleteSalle(id).subscribe(() => {
        this.fetchSalles();
      });
    }
  }
}
