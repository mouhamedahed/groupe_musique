import { Component, OnInit } from '@angular/core';
import { Concert, ConcertService } from '../../services/concert.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Salle, SalleService } from '../../services/salle-service.service';
import { Band, BandService } from '../../services/band-service.service';

@Component({
  selector: 'app-concerts',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './concerts.component.html',
  styleUrls: ['./concerts.component.css'],
})
export class ConcertsComponent implements OnInit {
  concerts: Concert[] = [];
  salles: Salle[] = [];
  bands: Band[] = [];
  newConcert: Concert = { name:'',date: '', salle: null, bands: [] };
  editingConcert: Concert | null = null;

  constructor(
    private concertService: ConcertService,
    private salleService: SalleService,
    private bandService: BandService
  ) {}

  ngOnInit() {
    this.loadConcerts();
    this.loadSalles();
    this.loadBands();
  }

  loadConcerts() {
    this.concertService.getConcerts().subscribe((data) => {
      this.concerts = data;
    });
    console.log('loadConcerts',     this.concerts)

  }

  loadSalles() {
    this.salleService.getSalles().subscribe((data) => {
      this.salles = data;
    });
  }

  loadBands() {
    this.bandService.getBands().subscribe((data) => {
      this.bands = data;
    });
  }

  addConcert() {
    if (!this.validateConcert(this.newConcert)) {
      alert("Erreur : Vérifiez que la salle et les groupes ne sont pas déjà réservés pour cette date.");
      return;
    }
    console.log("this.editingConcert",this.newConcert)

    this.concertService.addConcert(this.newConcert).subscribe(() => {
      this.loadConcerts();
      this.newConcert = {  name:'',date: '', salle: null, bands: [] };
    });
  }

  editConcert(concert: Concert) {
    this.editingConcert = { ...concert };
  }

  saveConcert() {
    if (this.editingConcert && this.editingConcert.id) {
      if (!this.validateConcert(this.editingConcert)) {
        alert("Erreur : Vérifiez que la salle et les groupes ne sont pas déjà réservés pour cette date.");
        return;
      }
     
      this.concertService.updateConcert(this.editingConcert.id, this.editingConcert).subscribe(() => {
        this.loadConcerts();
        this.editingConcert = null;
      });
    }
  }

  deleteConcert(id: any) {
    this.concertService.deleteConcert(id).subscribe(() => {
      this.loadConcerts();
    });
  }

  validateConcert(concert: Concert): boolean {
    return !this.concerts.some(c =>
      c.date === concert.date && (
        c.salle?.id === concert.salle?.id || 
        c.bands.some(b => concert.bands.includes(b))
      )
    );
  }


  toggleBandSelection(band: Band, event: any) {
    if (event.target.checked) {
      if (!this.newConcert.bands.some(b => b.id === band.id)) {
        this.newConcert.bands.push(band); 
      }
    } else {
      this.newConcert.bands = this.newConcert.bands.filter(b => b.id !== band.id);
    }
  }
  
  toggleBandSelectionEdit(band: any, event: any) {
    if (event.target.checked) {
      this.editingConcert?.bands.push(band);
    } else {
      this.editingConcert!.bands = this.editingConcert!.bands.filter(b => b.id !== band.id);
    }
  }
  
}
