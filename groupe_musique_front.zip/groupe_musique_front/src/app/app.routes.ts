import { Routes } from '@angular/router';
import { ConcertsComponent } from './components/concerts/concerts.component';
import { ImportBandsComponent } from './components/bands/bands.component';
import { HomeComponent } from './components/home/home.component';
import { SallesComponent } from './components/salles/salles.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },  // ✅ Home est bien défini
  { path: 'import-excel', component: ImportBandsComponent },
  { path: 'concerts', component: ConcertsComponent },
  { path: 'salles', component: SallesComponent },
  { path: '**', redirectTo: '' }  // ✅ Redirige vers Home par défaut
];
