import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
export interface Band {
  id?: number;
  name: string;
  origin: string;
  year_start: number;
  year_end?: number | null;
}

@Injectable({
  providedIn: 'root'
})
export class BandService {
  private apiUrl = 'http://localhost:8000/api/bands';

  constructor(private http: HttpClient) {}


  getBands(): Observable<Band[]> {
    return this.http.get<Band[]>(this.apiUrl);
  }

  // 📌 Récupérer un groupe par ID
  getBandById(id: number): Observable<Band> {
    return this.http.get<Band>(`${this.apiUrl}/${id}`);
  }

  // 📌 Ajouter un groupe
  createBand(band: Band): Observable<Band> {
    return this.http.post<Band>(this.apiUrl, band);
  }

  // 📌 Modifier un groupe
  updateBand(id: number, band: Band): Observable<Band> {
    return this.http.put<Band>(`${this.apiUrl}/${id}`, band);
  }

  // 📌 Supprimer un groupe
  deleteBand(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
