import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Concert {
  id?: number;
  name: string;
  date: string;
  salle: any;
  bands: any[];
}


@Injectable({
  providedIn: 'root'
})
export class ConcertService {
  private apiUrl = 'http://localhost:8000/api/concerts';

  constructor(private http: HttpClient) {}

  // Récupérer tous les concerts
  getConcerts(): Observable<Concert[]> {
    return this.http.get<Concert[]>(`${this.apiUrl}/`);
  }

  // Récupérer un concert par ID
  getConcertById(id: number): Observable<Concert> {
    return this.http.get<Concert>(`${this.apiUrl}/${id}`);
  }

  // Ajouter un concert
  addConcert(concert: Concert): Observable<any> {
    return this.http.post(`${this.apiUrl}/add`, concert);
  }

  // Modifier un concert
  updateConcert(id: number, concert: Concert): Observable<any> {
    return this.http.put(`${this.apiUrl}/edit/${id}`, concert);
  }

  // Supprimer un concert
  deleteConcert(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/delete/${id}`);
  }
}
