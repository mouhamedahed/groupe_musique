import { CommonModule } from '@angular/common'; 
import { Component } from '@angular/core';
import { RouterOutlet, RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,  // ✅ Ajout de standalone
  imports: [RouterOutlet, CommonModule, RouterModule], // ✅ Ajout de RouterModule
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'groupe_musique';
}
