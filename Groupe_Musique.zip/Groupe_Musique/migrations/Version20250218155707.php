<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20250218155707 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE band CHANGE year_start year_start INT DEFAULT NULL, CHANGE year_end year_end INT DEFAULT NULL, CHANGE membres_count membres_count INT DEFAULT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE band CHANGE year_start year_start INT NOT NULL, CHANGE year_end year_end INT NOT NULL, CHANGE membres_count membres_count INT NOT NULL');
    }
}
